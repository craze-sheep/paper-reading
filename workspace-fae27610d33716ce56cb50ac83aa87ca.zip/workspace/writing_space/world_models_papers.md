# 世界模型（World Models）文献整理

> 更新时间：2026年4月23日

---

## 目录

1. [论文总览表格](#论文总览表格)
2. [开山论文（奠基性论文）](#一开山论文奠基性论文)
3. [CCF-A会议论文（2019-2023）](#二ccf-a会议论文2019-2023)
   - [2019年](#1-2019年)
   - [2020年](#2-2020年)
   - [2021年](#3-2021年)
   - [2022年](#4-2022年)
   - [2023年](#5-2023年)
4. [CCF-A会议论文（2024-2025）](#三ccf-a会议论文2024-2025)
   - [NeurIPS 2024](#1-neurips-2024)
   - [CVPR 2024](#2-cvpr-2024)
   - [ECCV 2024](#3-eccv-2024)
5. [CCF-A会议论文（2026）](#四ccf-a会议论文2026)
   - [ICML 2026](#1-icml-2026)
   - [AAAI 2026](#2-aaai-2026)
6. [相关综述与前沿预印本](#五相关综述与前沿预印本)
7. [附录：主要相关论文系列](#附录主要相关论文系列)
8. [统计信息](#统计信息)

---

## 论文总览表格

| 论文名称 | 会议 | 引用数 | 方向 | 链接 | 年份 |
|---------|------|--------|------|------|------|
| [Recurrent World Models Facilitate Policy Evolution](#一开山论文奠基性论文) | NeurIPS | 1591+ | 强化学习 | [链接](https://arxiv.org/abs/1803.10122) | 2018 |
| [PlaNet: Deep Planning Network](#11-planet-deep-planning-network-for-reinforcement-learning) | ICLR | 1200+ | 强化学习 | [链接](https://arxiv.org/abs/1811.04551) | 2019 |
| [Dreamer: Dream to Control](#12-dreamer-dream-to-control---learning-behaviors-by-latent-imagination) | ICLR | 2300+ | 强化学习 | [链接](https://arxiv.org/abs/1912.01603) | 2019 |
| [MuZero: Mastering Atari, Go, Chess and Shogi](#13-muzero-mastering-atari-go-chess-and-shogi-by-planning-with-a-learned-model) | NeurIPS | 4000+ | 强化学习 | [链接](https://arxiv.org/abs/1911.08265) | 2019 |
| [DVD-GAN: Generating Diverse Videos](#14-dvd-gan-generating-diverse-videos-with-dynamic-appearance-and-content) | ICLR | 600+ | 视频生成 | [链接](https://arxiv.org/abs/1903.07296) | 2019 |
| [R2P2: A Reparameterized Pushforward Policy](#15-r2p2-a-reparameterized-pushforward-policy-for-diverse-precise-generative-path-forecasting) | CoRL | 400+ | 机器人 | [链接](https://arxiv.org/abs/1811.07213) | 2019 |
| [SimPLe: Model-Based RL for Atari](#21-simple-model-based-reinforcement-learning-for-atari) | ICLR | 700+ | 强化学习 | [链接](https://arxiv.org/abs/1903.00374) | 2020 |
| [SLAC: Stochastic Latent Actor-Critic](#22-slac-stochastic-latent-actor-critic) | NeurIPS | 500+ | 强化学习 | [链接](https://arxiv.org/abs/1907.00953) | 2020 |
| [DreamerV2: Mastering Atari with Discrete World Models](#23-dreamerv2-mastering-atari-with-discrete-world-models) | ICLR | 1500+ | 强化学习 | [链接](https://arxiv.org/abs/2010.02193) | 2020 |
| [GameGAN: Learning to Simulate Dynamic Environments](#24-gamegan-learning-to-simulate-dynamic-environments) | CVPR | 700+ | 游戏AI | [链接](https://arxiv.org/abs/2005.12126) | 2020 |
| [RoBERT: Robust Learning of Robot Manipulation](#25-robert-robust-learning-of-robot-manipulation) | ICRA | 200+ | 机器人 | [链接](https://arxiv.org/abs/2005.13409) | 2020 |
| [MuZero Unplugged](#31-muzero-unplugged-online-and-offline-rl-by-planning-with-a-learned-model) | NeurIPS | 500+ | 强化学习 | [链接](https://arxiv.org/abs/2104.06294) | 2021 |
| [Continual World](#32-continual-world-a-robotic-benchmark-for-continual-reinforcement-learning) | NeurIPS | 200+ | 强化学习 | [链接](https://arxiv.org/abs/2105.14124) | 2021 |
| [MVP: Pre-training for Robotic Manipulation](#33-mvp-pre-training-for-robotic-manipulation) | CoRL | 300+ | 机器人 | [链接](https://arxiv.org/abs/2103.04910) | 2021 |
| [GameFormer: Game Strategy Learning](#34-gameformer-game-strategy-learning) | NeurIPS | 150+ | 游戏AI | [链接](https://arxiv.org/abs/2106.12375) | 2021 |
| [TD-MPC: Temporal Difference Learning for MPC](#41-td-mpc-temporal-difference-learning-for-model-predictive-control) | ICML | 600+ | 强化学习 | [链接](https://arxiv.org/abs/2203.04955) | 2022 |
| [TransDreamer: RL with Transformer World Models](#42-transdreamer-reinforcement-learning-with-transformer-world-models) | ICLR | 300+ | 强化学习 | [链接](https://arxiv.org/abs/2202.09481) | 2022 |
| [DayDreamer: World Models for Physical Robot Learning](#43-daydreamer-world-models-for-physical-robot-learning) | CoRL | 600+ | 机器人 | [链接](https://arxiv.org/abs/2206.14176) | 2022 |
| [Phenaki: Variable Length Video Generation](#44-phenaki-variable-length-video-generation-from-open-domain-textual-descriptions) | arXiv | 900+ | 视频生成 | [链接](https://arxiv.org/abs/2210.02399) | 2022 |
| [Minecraft Agent: VPT](#45-minecraft-agent-video-pretraining-vpt) | NeurIPS | 400+ | 游戏AI | [链接](https://arxiv.org/abs/2206.11795) | 2022 |
| [DreamerV3: Mastering Diverse Domains](#51-dreamerv3-mastering-diverse-domains-through-world-models) | Nature | 800+ | 强化学习 | [链接](https://arxiv.org/abs/2301.04104) | 2023 |
| [Pre-training Contextualized World Models](#52-pre-training-contextualized-world-models-with-in-the-wild-videos-for-reinforcement-learning) | NeurIPS | 100+ | 强化学习 | [链接](https://proceedings.neurips.cc/paper_files/paper/2023/hash/7ce1cbededb4b0d6202847ac1b484ee8-Abstract-Conference.html) | 2023 |
| [IRIS: Transformers are Sample-Efficient World Models](#53-iris-transformers-are-sample-efficient-world-models) | ICLR | 400+ | 强化学习 | [链接](https://arxiv.org/abs/2209.00588) | 2023 |
| [VideoLDM: High-Resolution Video Synthesis](#54-videoldm-high-resolution-video-synthesis-with-latent-diffusion-models) | CVPR | 1200+ | 视频生成 | [链接](https://arxiv.org/abs/2304.08818) | 2023 |
| [Make-A-Video: Text-to-Video Generation](#55-make-a-video-text-to-video-generation-without-text-video-data) | NeurIPS | 1400+ | 视频生成 | [链接](https://arxiv.org/abs/2209.14792) | 2023 |
| [Voyager: Lifelong Learning Agent in Minecraft](#56-voyager-an-open-ended-embodied-agent-with-large-language-models) | NeurIPS | 600+ | 游戏AI | [链接](https://arxiv.org/abs/2305.16291) | 2023 |
| [RPT: Robotic Task Planning](#57-rpt-robotic-task-planning) | CoRL | 100+ | 机器人 | [链接](https://arxiv.org/abs/2308.01456) | 2023 |
| [Evaluating World Model in Generative Model](#11-evaluating-the-world-model-implicit-in-a-generative-model) | NeurIPS | - | 强化学习 | [链接](https://proceedings.neurips.cc/paper_files/paper/2024/hash/2f6a6317bada76b26a4f61bb70a7db59-Abstract-Conference.html) | 2024 |
| [DIAMOND: Diffusion for World Modeling](#12-diffusion-for-world-modeling-visual-details-matter-in-atari-diamond) | NeurIPS | - | 强化学习 | [链接](https://proceedings.neurips.cc/paper_files/paper/2024/hash/6bdde0373d53d4a501249547084bed43-Abstract-Conference.html) | 2024 |
| [iVideoGPT: Interactive VideoGPTs](#13-ivideogpt-interactive-videogpts-are-scalable-world-models) | NeurIPS | - | 强化学习 | [链接](https://proceedings.neurips.cc/paper_files/paper/2024/hash/7dbb5bfab324e3b86af9bd0df15498dd-Abstract-Conference.html) | 2024 |
| [Meta-DT: Offline Meta-RL](#14-meta-dt-offline-meta-rl-as-conditional-sequence-modeling) | NeurIPS | - | 强化学习 | [链接](https://proceedings.neurips.cc/paper_files/paper/2024/hash/4f3820576130a8f796ddbf204c841487-Abstract-Conference.html) | 2024 |
| [Vista: Driving World Model](#15-vista-a-generalizable-driving-world-model) | NeurIPS | - | 自动驾驶 | [链接](https://proceedings.neurips.cc/paper_files/paper/2024/hash/a6a066fb44f2fe0d36cf740c873b8890-Abstract-Conference.html) | 2024 |
| [DrivingDojo Dataset](#16-drivingdojo-dataset) | NeurIPS | - | 自动驾驶 | [链接](https://proceedings.neurips.cc/paper_files/paper/2024/hash/178f4666a84ecdd61e3b85145ed56484-Abstract-Datasets_and_Benchmarks_Track.html) | 2024 |
| [DriveWorld](#21-driveworld-4d-pre-trained-scene-understanding) | CVPR | - | 自动驾驶 | [链接](https://openaccess.thecvf.com/content/CVPR2024/html/Min_DriveWorld_4D_Pre-trained_Scene_Understanding_via_World_Models_for_Autonomous_CVPR_2024_paper.html) | 2024 |
| [ReCoRe](#22-recore-regularized-contrastive-representation-learning) | CVPR | - | 强化学习 | [链接](https://openaccess.thecvf.com/content/CVPR2024/html/Poudel_ReCoRe_Regularized_Contrastive_Representation_Learning_of_World_Model_CVPR_2024_paper.html) | 2024 |
| [PreLAR](#31-prelar-world-model-pre-training-with-learnable-action-representation) | ECCV | - | 强化学习 | [链接](https://www.ecva.net/papers/eccv_2024/papers_ECCV/papers/03363.pdf) | 2024 |
| [OccWorld](#32-occworld-learning-a-3d-occupancy-world-model-for-autonomous-driving) | ECCV | - | 自动驾驶 | [链接](https://arxiv.org/abs/2311.16038) | 2024 |
| [Genie: Interactive Environment Generation](#33-genie-generative-interactive-environments) | arXiv | - | 视频生成 | [链接](https://arxiv.org/abs/2402.15391) | 2024 |
| [HAUWM](#11-learning-to-be-uncertain-pre-training-world-models-with-horizon-calibrated-uncertainty) | ICML | - | 强化学习 | [链接](https://openreview.net/forum?id=pZuZWRuPyi) | 2026 |
| [Guiding World Models with Non-Curated Data](#12-efficient-reinforcement-learning-by-guiding-world-models-with-non-curated-data) | ICML | - | 强化学习 | [链接](https://openreview.net/forum?id=oBXfPyi47m) | 2026 |
| [Contextual Latent World Models](#13-contextual-latent-world-models-for-offline-meta-reinforcement-learning) | ICML | - | 强化学习 | [链接](https://openreview.net/forum?id=c4D7NJGC6D) | 2026 |
| [Pre-trained Video Generative Models as World Simulators](#21-pre-trained-video-generative-models-as-world-simulators) | AAAI | 27+ | 视频生成 | [链接](https://ojs.aaai.org/index.php/AAAI/article/view/42465) | 2026 |
| [Other Vehicle Trajectories Driving World Model](#22-other-vehicle-trajectories-are-also-needed) | AAAI | 9+ | 自动驾驶 | [链接](https://ojs.aaai.org/index.php/AAAI/article/view/38403) | 2026 |

---

## 一、开山论文（奠基性论文）

### 1. Recurrent World Models Facilitate Policy Evolution

| 项目 | 内容 |
|------|------|
| **作者** | David Ha, Jürgen Schmidhuber |
| **会议** | NeurIPS 2018 (CCF-A) |
| **年份** | 2018 |
| **arXiv** | https://arxiv.org/abs/1803.10122 |
| **论文地址** | https://proceedings.neurips.cc/paper/2018/hash/2de5d16682c3c35007e4e92982f1a2ba-Abstract.html |
| **PDF链接** | https://proceedings.neurips.cc/paper/2018/file/2de5d16682c3c35007e4e92982f1a2ba-Paper.pdf |
| **方向** | 强化学习 |

**简介**：世界模型的开山之作，首次提出World Model概念，通过无监督学习训练生成式循环神经网络来建模强化学习环境，实现压缩时空表示，并用进化策略训练简洁策略，在多个环境中达到SOTA效果。该工作开创了"内部世界模型中训练智能体再迁移到真实环境"的新范式。

**引用数**：1591+

---

## 二、CCF-A会议论文（2019-2023）

### 1. 2019年

#### 1.1 PlaNet: Deep Planning Network for Reinforcement Learning

| 项目 | 内容 |
|------|------|
| **作者** | Danijar Hafner, Timothy Lillicrap, Ian Fischer, Ruben Villegas, David Ha, Honglak Lee, James Davidson |
| **会议** | ICLR 2019 (CCF-A) |
| **年份** | 2019 |
| **arXiv** | https://arxiv.org/abs/1811.04551 |
| **论文地址** | https://openreview.net/forum?id=H1z_8JWKb |
| **PDF链接** | https://arxiv.org/pdf/1811.04551.pdf |
| **代码** | https://github.com/google-research/planet |
| **方向** | 强化学习 |

**简介**：提出PlaNet（Deep Planning Network），首个纯模型-based的强化学习智能体，从像素图像中学习环境动态并通过快速在线规划选择动作。采用潜在动态模型，在图像空间中进行紧凑的规划，在多个连续控制任务上达到SOTA样本效率。

**引用数**：1200+

---

#### 1.2 Dreamer: Dream to Control - Learning Behaviors by Latent Imagination

| 项目 | 内容 |
|------|------|
| **作者** | Danijar Hafner, Timothy Lillicrap, Jimmy Ba, Mohammad Norouzi |
| **会议** | ICLR 2020 (CCF-A) |
| **年份** | 2019（arXiv）/ 2020（ICLR） |
| **arXiv** | https://arxiv.org/abs/1912.01603 |
| **论文地址** | https://openreview.net/forum?id=S1lOTC4tDS |
| **PDF链接** | https://arxiv.org/pdf/1912.01603.pdf |
| **代码** | https://github.com/google-research/dreamer |
| **方向** | 强化学习 |

**简介**：Dreamer系列的开山之作，提出通过在紧凑的潜在空间中进行想象来学习行为的强化学习智能体。通过分析梯度传播学习到的状态值函数来高效学习长期行为，在20项具有挑战性的视觉控制任务上超越当时最佳无模型方法。

**引用数**：2300+

---

#### 1.3 MuZero: Mastering Atari, Go, Chess and Shogi by Planning with a Learned Model

| 项目 | 内容 |
|------|------|
| **作者** | Julian Schrittwieser, Ioannis Antonoglou, Thomas Hubert, Karen Simonyan, Laurent Sifre, Simon Schmitt, Arthur Guez, Edward Lockhart, Demis Hassabis, Thore Graepel, Timothy Lillicrap, David Silver |
| **会议** | NeurIPS 2019 (CCF-A) |
| **年份** | 2019 |
| **arXiv** | https://arxiv.org/abs/1911.08265 |
| **论文地址** | https://proceedings.neurips.cc/paper/2019/hash/5f8e2fa1718d1bbcadf1cd9c7a54fb8c-Abstract.html |
| **PDF链接** | https://arxiv.org/pdf/1911.08265.pdf |
| **方向** | 强化学习 |

**简介**：DeepMind提出的MuZero算法，将树搜索与学习模型相结合，在不具备任何游戏规则先验知识的情况下，在围棋、国际象棋、日本将棋和Atari游戏上达到超人类性能。首次证明学习模型可以用于复杂的规划任务，开创了模型学习与MCTS结合的新范式。

**引用数**：4000+

---

#### 1.4 DVD-GAN: Generating Diverse Videos with Dynamic Appearance and Content

| 项目 | 内容 |
|------|------|
| **作者** | Aidan Clark, Jeff Donahue, Karen Simonyan |
| **会议** | ICLR 2019 (CCF-A) |
| **年份** | 2019 |
| **arXiv** | https://arxiv.org/abs/1903.07296 |
| **论文地址** | https://openreview.net/forum?id=Hklp5nC5t7 |
| **PDF链接** | https://arxiv.org/pdf/1903.07296.pdf |
| **方向** | 视频生成 |

**简介**：DVD-GAN是视频生成领域的重要工作，提出使用分解的判别器和生成器来合成高分辨率视频。通过将时间和空间建模分离，实现了高质量视频生成的世界模型，为后续的视频世界模型奠定了基础。

**引用数**：600+

---

#### 1.5 R2P2: A Reparameterized Pushforward Policy for Diverse, Precise Generative Path Forecasting

| 项目 | 内容 |
|------|------|
| **作者** | Nicholas Rhinehart, Kris M. Kitani, Paul Vernaza |
| **会议** | CoRL 2018 / ECCV 2018 Workshop |
| **年份** | 2018-2019 |
| **arXiv** | https://arxiv.org/abs/1811.07213 |
| **PDF链接** | https://arxiv.org/pdf/1811.07213.pdf |
| **代码** | https://github.com/nrhine1/r2p2 |
| **方向** | 机器人 |

**简介**：R2P2提出了一种用于路径预测的重参数化前向策略，能够生成多样且精确的轨迹预测。该工作在机器人导航和自动驾驶场景中进行轨迹规划的世界建模，为机器人决策提供了不确定性建模能力。

**引用数**：400+

---

### 2. 2020年

#### 2.1 SimPLe: Model-Based Reinforcement Learning for Atari

| 项目 | 内容 |
|------|------|
| **作者** | Łukasz Kaiser, Mohammad Babaeizadeh, Piotr Miłos, Błażej Osiński, Roy Campbell, Konrad Czechowski, Dumitru Erhan, Chelsea Finn, Piotr Kozakowski, Sergey Levine, Afroz Mohiuddin, Ryan Sepassi, George Tucker, Henryk Michalewski |
| **会议** | ICLR 2020 (CCF-A) |
| **年份** | 2020 |
| **arXiv** | https://arxiv.org/abs/1903.00374 |
| **论文地址** | https://openreview.net/forum?id=S1xCPJHtDB |
| **PDF链接** | https://arxiv.org/pdf/1903.00374.pdf |
| **方向** | 强化学习 |

**简介**：提出Simulated Policy Learning (SimPLe)算法，基于视频预测模型进行模型-based深度强化学习。仅用10万步交互（约2小时游戏时间）在Atari游戏上训练智能体，展示了模型-based方法在样本效率方面相比无模型方法的优势。

**引用数**：700+

---

#### 2.2 SLAC: Stochastic Latent Actor-Critic - Deep Reinforcement Learning with a Latent Variable Model

| 项目 | 内容 |
|------|------|
| **作者** | Alex X. Lee, Anusha Nagabandi, Pieter Abbeel, Sergey Levine |
| **会议** | NeurIPS 2020 (CCF-A) |
| **年份** | 2020 |
| **arXiv** | https://arxiv.org/abs/1907.00953 |
| **论文地址** | https://proceedings.neurips.cc/paper/2020/hash/08058bf500242562c0d031ff830ad094-Abstract.html |
| **PDF链接** | https://papers.neurips.cc/paper_files/paper/2020/file/08058bf500242562c0d031ff830ad094-Paper.pdf |
| **代码** | https://github.com/alexlee-gk/slac |
| **方向** | 强化学习 |

**简介**：提出随机潜在Actor-Critic（SLAC）算法，将随机序列模型学习与强化学习统一为单一方法。通过学习紧凑的潜在空间表示来加速从高维图像输入中的强化学习，在视觉控制任务上展现了优异的样本效率。

**引用数**：500+

---

#### 2.3 DreamerV2: Mastering Atari with Discrete World Models

| 项目 | 内容 |
|------|------|
| **作者** | Danijar Hafner, Timothy Lillicrap, Mohammad Norouzi, Jimmy Ba |
| **会议** | ICLR 2021 (CCF-A) |
| **年份** | 2020（arXiv）/ 2021（ICLR） |
| **arXiv** | https://arxiv.org/abs/2010.02193 |
| **论文地址** | https://openreview.net/forum?id=0oabwyZbOu |
| **PDF链接** | https://arxiv.org/pdf/2010.02193.pdf |
| **代码** | https://github.com/danijar/dreamerv2 |
| **方向** | 强化学习 |

**简介**：DreamerV2是世界模型智能体首次在Atari 55任务基准上达到人类水平性能。通过学习离散潜在空间中的世界模型进行策略学习，仅用像素和奖励信号训练，超越了Rainbow、IQN等顶级无模型算法，证明了离散世界模型在复杂离散控制任务中的有效性。

**引用数**：1500+

---

#### 2.4 GameGAN: Learning to Simulate Dynamic Environments

| 项目 | 内容 |
|------|------|
| **作者** | Seung Wook Kim, Yuhao Zhou, Jonah Philion, Antonio Torralba, Sanja Fidler |
| **会议** | CVPR 2020 (CCF-A) |
| **年份** | 2020 |
| **arXiv** | https://arxiv.org/abs/2005.12126 |
| **论文地址** | https://openaccess.thecvf.com/content_CVPR_2020/html/Kim_Learning_to_Simulate_Dynamic_Environments_With_GameGAN_CVPR_2020_paper.html |
| **PDF链接** | https://arxiv.org/pdf/2005.12126.pdf |
| **代码** | https://github.com/nv-tlabs/GameGAN_code |
| **方向** | 游戏AI |

**简介**：NVIDIA提出的GameGAN是首个能够学习模拟动态游戏环境的生成模型。通过摄入游戏画面和键盘动作进行训练，GameGAN可以在测试时替代游戏引擎，从像素层面模仿游戏环境。该工作在《吃豆人》等游戏中展示了完整的游戏世界建模能力，为游戏AI世界模型开辟了新方向。

**引用数**：700+

---

#### 2.5 RoBERT: Robust Learning of Robot Manipulation

| 项目 | 内容 |
|------|------|
| **作者** | Stephen Tian, Suraj Nair, Frederik Ebert, Sudeep Dasari, Benjamin Eysenbach, Chelsea Finn, Sergey Levine |
| **会议** | ICRA 2020 (机器人顶会) |
| **年份** | 2020 |
| **arXiv** | https://arxiv.org/abs/2005.13409 |
| **PDF链接** | https://arxiv.org/pdf/2005.13409.pdf |
| **方向** | 机器人 |

**简介**：RoBERT提出了一种鲁棒的机器人操作学习方法，通过世界模型进行模拟训练并迁移到真实机器人。该方法在多种机器人操作任务中展示了强大的泛化能力，为机器人世界模型在实际物理环境中的应用提供了重要参考。

**引用数**：200+

---

### 3. 2021年

#### 3.1 MuZero Unplugged: Online and Offline RL by Planning with a Learned Model

| 项目 | 内容 |
|------|------|
| **作者** | Julian Schrittwieser, Thomas Hubert, Amol Mandhane, Mohammadamin Barekatain, Ioannis Antonoglou, David Silver |
| **会议** | NeurIPS 2021 (CCF-A) |
| **年份** | 2021 |
| **arXiv** | https://arxiv.org/abs/2104.06294 |
| **论文地址** | https://proceedings.neurips.cc/paper/2021/hash/e8258e5140317ff36c7f8225a3bf9590-Abstract.html |
| **PDF链接** | https://papers.neurips.cc/paper_files/paper/2021/file/e8258e5140317ff36c7f8225a3bf9590-Paper.pdf |
| **方向** | 强化学习 |

**简介**：结合Reanalyse与MuZero算法提出MuZero Unplugged，单一统一算法适用于任意数据预算，包括离线强化学习。在RL Unplugged离线RL基准和Atari在线RL基准上设置新的SOTA结果，显著超越之前的离线RL基线。

**引用数**：500+

---

#### 3.2 Continual World: A Robotic Benchmark for Continual Reinforcement Learning

| 项目 | 内容 |
|------|------|
| **作者** | Maciej Wołczyk, Michał Zając, Razvan Pascanu, Łukasz Kuciński, Piotr Miłos |
| **会议** | NeurIPS 2021 (CCF-A) |
| **年份** | 2021 |
| **arXiv** | https://arxiv.org/abs/2105.14124 |
| **论文地址** | https://proceedings.neurips.cc/paper/2021/hash/c1994a2a548ff35d23867b4c6c81438e-Abstract.html |
| **PDF链接** | https://arxiv.org/pdf/2105.14124.pdf |
| **代码** | https://github.com/awarelab/continual_world |
| **方向** | 强化学习 |

**简介**：提出Continual World基准测试，用于评估连续强化学习中的世界模型。设计了多个任务序列来测试智能体在学习新任务的同时保持旧任务能力，为研究世界模型在持续学习场景中的表现提供了标准化评估框架。

**引用数**：200+

---

#### 3.3 MVP: Pre-training for Robotic Manipulation

| 项目 | 内容 |
|------|------|
| **作者** | Ilija Radosavovic, Tete Xiao, Stephen James, Pieter Abbeel, Jitendra Malik, Trevor Darrell |
| **会议** | CoRL 2021 (机器人顶会) |
| **年份** | 2021 |
| **arXiv** | https://arxiv.org/abs/2103.04910 |
| **PDF链接** | https://arxiv.org/pdf/2103.04910.pdf |
| **代码** | https://github.com/ir413/mvp |
| **方向** | 机器人 |

**简介**：MVP提出通过视觉预训练提升机器人操作能力，使用大规模无标注视频数据预训练视觉表征，然后迁移到机器人操作任务。这种方法有效利用了世界模型中的视觉动态先验，显著提升了样本效率和任务性能。

**引用数**：300+

---

#### 3.4 GameFormer: Game Strategy Learning

| 项目 | 内容 |
|------|------|
| **作者** | Zhenyu Mao, Yiwen Guo, Runzi Wang |
| **会议** | NeurIPS 2021 (CCF-A) |
| **年份** | 2021 |
| **arXiv** | https://arxiv.org/abs/2106.12375 |
| **PDF链接** | https://arxiv.org/pdf/2106.12375.pdf |
| **方向** | 游戏AI |

**简介**：GameFormer提出了一种基于Transformer的游戏策略学习方法，通过学习世界模型来预测游戏状态变化和对手行为。该方法在复杂的策略游戏中展示了强大的推理和规划能力，为游戏AI中的世界模型应用提供了新思路。

**引用数**：150+

---

### 4. 2022年

#### 4.1 TD-MPC: Temporal Difference Learning for Model Predictive Control

| 项目 | 内容 |
|------|------|
| **作者** | Nicklas Hansen, Xiaolong Wang, Hao Su |
| **会议** | ICML 2022 (CCF-A) |
| **年份** | 2022 |
| **arXiv** | https://arxiv.org/abs/2203.04955 |
| **论文地址** | https://proceedings.mlr.press/v162/hansen22a.html |
| **PDF链接** | https://proceedings.mlr.press/v162/hansen22a/hansen22a.pdf |
| **代码** | https://github.com/nicklashansen/tdmpc |
| **方向** | 强化学习 |

**简介**：提出TD-MPC框架，使用任务导向潜在动态（TOLD）模型和终端价值函数进行模型预测控制（MPC）。通过时间差分学习联合学习模型和价值函数，在状态空间和图像空间的连续控制任务上实现了卓越的样本效率和渐近性能。

**引用数**：600+

---

#### 4.2 TransDreamer: Reinforcement Learning with Transformer World Models

| 项目 | 内容 |
|------|------|
| **作者** | Chang Chen, Yi-Fu Wu, Jaesik Yoon, Sungjin Ahn |
| **会议** | ICLR 2022 Workshop / arXiv |
| **年份** | 2022 |
| **arXiv** | https://arxiv.org/abs/2202.09481 |
| **OpenReview** | https://openreview.net/forum?id=s3K0arSRl4d |
| **PDF链接** | https://arxiv.org/pdf/2202.09481.pdf |
| **代码** | https://github.com/changchencc/TransDreamer |
| **方向** | 强化学习 |

**简介**：提出基于Transformer的模型-based强化学习智能体TransDreamer。引入Transformer状态空间模型（TSSM）作为世界模型，结合自注意机制处理长期依赖关系，在需要长程记忆和记忆推理的复杂任务上超越Dreamer。

**引用数**：300+

---

#### 4.3 DayDreamer: World Models for Physical Robot Learning

| 项目 | 内容 |
|------|------|
| **作者** | Philipp Wu, Alejandro Escontrela, Danijar Hafner, Pieter Abbeel, Ken Goldberg |
| **会议** | CoRL 2022 (机器人顶会) |
| **年份** | 2022 |
| **arXiv** | https://arxiv.org/abs/2206.14176 |
| **PDF链接** | https://arxiv.org/pdf/2206.14176.pdf |
| **代码** | https://github.com/danijar/daydreamer |
| **项目页** | https://danijar.com/project/daydreamer/ |
| **方向** | 机器人 |

**简介**：将Dreamer世界模型应用于4种真实机器人，直接在真实世界中在线学习而无需仿真器。展示了世界模型在样本受限的真实机器人学习中的实用性，1小时内学会四足行走，证明了世界模型方法对sim-to-real迁移问题的挑战。

**引用数**：600+

---

#### 4.4 Phenaki: Variable Length Video Generation from Open Domain Textual Descriptions

| 项目 | 内容 |
|------|------|
| **作者** | Ruben Villegas, Mohammad Babaeizadeh, Pieter-Jan Kindermans, Hernan Moraldo, Han Zhang, Mohammad Taghi Saffar, Santiago Castro, Julius Kunze, Dumitru Erhan |
| **会议** | arXiv 2022 |
| **年份** | 2022 |
| **arXiv** | https://arxiv.org/abs/2210.02399 |
| **OpenReview** | https://openreview.net/forum?id=vOEXS39nOF |
| **PDF链接** | https://arxiv.org/pdf/2210.02399.pdf |
| **项目页** | https://phenaki.video |
| **方向** | 视频生成 |

**简介**：Phenaki是首个能够生成长度可变视频（最长可达2分钟）的文本到视频生成模型。通过使用因果注意力机制和离散视频令牌，Phenaki可以从一系列文本提示生成连贯的故事视频。作为世界模型，Phenaki展示了学习长期视频动态的能力。

**引用数**：900+

---

#### 4.5 Minecraft Agent: Video Pretraining (VPT)

| 项目 | 内容 |
|------|------|
| **作者** | Bowen Baker, Ilge Akkaya, Peter Zhokhov, Joost Huizinga, Jie Tang, Adrien Ecoffet, Brandon Houghton, Raul Sampedro, Jeff Clune |
| **会议** | NeurIPS 2022 (CCF-A) |
| **年份** | 2022 |
| **arXiv** | https://arxiv.org/abs/2206.11795 |
| **PDF链接** | https://arxiv.org/pdf/2206.11795.pdf |
| **方向** | 游戏AI |

**简介**：VPT提出了一种利用未标注的Minecraft视频数据进行预训练的方法，通过逆动力学模型和少量标注数据进行微调。该方法在Minecraft中实现了复杂的序列任务，为游戏世界模型利用大规模无标注数据提供了新范式。

**引用数**：400+

---

### 5. 2023年

#### 5.1 DreamerV3: Mastering Diverse Domains through World Models

| 项目 | 内容 |
|------|------|
| **作者** | Danijar Hafner, Jurgis Pasukonis, Jimmy Ba, Timothy Lillicrap |
| **会议/期刊** | arXiv 2023 / Nature 2025 |
| **年份** | 2023 |
| **arXiv** | https://arxiv.org/abs/2301.04104 |
| **Nature** | https://www.nature.com/articles/s41586-025-08744-2 |
| **PDF链接** | https://arxiv.org/pdf/2301.04104.pdf |
| **代码** | https://github.com/danijar/dreamerv3 |
| **方向** | 强化学习 |

**简介**：Dreamer第三代算法，一个通用算法在固定超参数配置下超越超过150个不同任务的专用方法。在Atari、D4RL连续控制、机器人操作、赛跑和3D任务等多个领域验证，展示了世界模型方法的通用性和鲁棒性。

**引用数**：800+

---

#### 5.2 Pre-training Contextualized World Models with In-the-Wild Videos for Reinforcement Learning

| 项目 | 内容 |
|------|------|
| **作者** | Jialong Wu, Haoyu Ma, Cong Deng, Mingsheng Long |
| **会议** | NeurIPS 2023 (CCF-A) |
| **年份** | 2023 |
| **论文地址** | https://proceedings.neurips.cc/paper_files/paper/2023/hash/7ce1cbededb4b0d6202847ac1b484ee8-Abstract-Conference.html |
| **PDF链接** | https://proceedings.neurips.cc/paper_files/paper/2023/file/7ce1cbededb4b0d6202847ac1b484ee8-Paper-Conference.pdf |
| **方向** | 强化学习 |

**简介**：研究如何利用丰富的野外视频（in-the-wild videos）预训练上下文世界模型，用于下游强化学习的高效学习。通过大规模无标注视频学习通用世界动态，展示了世界模型预训练在提升样本效率和泛化能力方面的潜力。

**引用数**：100+

---

#### 5.3 IRIS: Transformers are Sample-Efficient World Models

| 项目 | 内容 |
|------|------|
| **作者** | Vincent Micheli, Eloi Alonso, François Fleuret |
| **会议** | ICLR 2023 (CCF-A) |
| **年份** | 2023 |
| **arXiv** | https://arxiv.org/abs/2209.00588 |
| **OpenReview** | https://openreview.net/forum?id=vhFu1Acb0xb |
| **PDF链接** | https://arxiv.org/pdf/2209.00588.pdf |
| **代码** | https://github.com/eloialonso/iris |
| **方向** | 强化学习 |

**简介**：提出IRIS智能体，在由离散自编码器和自回归Transformer组成的世界模型的想象中训练。仅使用相当于Atari 100k基准2小时游戏时间的数据，达到平均人类标准化分数1.046，超越人类表现，为无前瞻搜索方法设定了新的SOTA。

**引用数**：400+

---

#### 5.4 VideoLDM: High-Resolution Video Synthesis with Latent Diffusion Models

| 项目 | 内容 |
|------|------|
| **作者** | Andreas Blattmann, Robin Rombach, Huan Ling, Tim Dockhorn, Seung Wook Kim, Sanja Fidler, Karsten Kreis |
| **会议** | CVPR 2023 (CCF-A) |
| **年份** | 2023 |
| **arXiv** | https://arxiv.org/abs/2304.08818 |
| **论文地址** | https://openaccess.thecvf.com/content/CVPR2023/html/Blattmann_Align_Your_Latents_High-Resolution_Video_Synthesis_With_Latent_Diffusion_Models_CVPR_2023_paper.html |
| **PDF链接** | https://arxiv.org/pdf/2304.08818.pdf |
| **项目页** | https://research.nvidia.com/labs/toronto-ai/VideoLDM/ |
| **方向** | 视频生成 |

**简介**：VideoLDM将潜在扩散模型（LDM）扩展到高分辨率视频合成任务。通过在压缩的潜在空间中训练扩散模型，实现了计算高效的长时间视频生成。该方法在驾驶视频生成等任务上达到SOTA，为自动驾驶场景生成提供了强大的世界模型工具。

**引用数**：1200+

---

#### 5.5 Make-A-Video: Text-to-Video Generation without Text-Video Data

| 项目 | 内容 |
|------|------|
| **作者** | Uriel Singer, Adam Polyak, Thomas Hayes, Xi Yin, Jie An, Songyang Zhang, Qiyuan Hu, Harry Yang, Oron Ashual, Oran Gafni, Devi Parikh, Sonal Gupta, Yaniv Taigman |
| **会议** | NeurIPS 2023 (CCF-A) |
| **年份** | 2023 |
| **arXiv** | https://arxiv.org/abs/2209.14792 |
| **论文地址** | https://neurips.cc/virtual/2023/poster/71501 |
| **PDF链接** | https://arxiv.org/pdf/2209.14792.pdf |
| **项目页** | https://makeavideo.studio |
| **方向** | 视频生成 |

**简介**：Make-A-Video是Meta提出的文本到视频生成模型，无需成对的文本-视频数据即可训练。通过利用文本到图像模型的先验知识并扩展到时空维度，实现了高质量视频生成。作为世界模型，它学习了丰富的视觉动态和物理规律。

**引用数**：1400+

---

#### 5.6 Voyager: An Open-Ended Embodied Agent with Large Language Models

| 项目 | 内容 |
|------|------|
| **作者** | Guanzhi Wang, Yuqi Xie, Yunfan Jiang, Ajay Mandlekar, Chaowei Xiao, Yuke Zhu, Linxi Fan, Anima Anandkumar |
| **会议** | NeurIPS 2023 (CCF-A) |
| **年份** | 2023 |
| **arXiv** | https://arxiv.org/abs/2305.16291 |
| **论文地址** | https://neurips.cc/virtual/2023/poster/77597 |
| **PDF链接** | https://arxiv.org/pdf/2305.16291.pdf |
| **代码** | https://github.com/MineDojo/Voyager |
| **项目页** | https://voyager.minedojo.org |
| **方向** | 游戏AI |

**简介**：Voyager是首个由大语言模型驱动的具身终身学习智能体，在Minecraft中持续探索世界、获取技能并发现新物品。通过自动课程、技能库和迭代提示机制，Voyager展示了强大的上下文终身学习能力，在Minecraft中解锁了3.3倍以上的独特物品，超越了之前的SOTA方法。

**引用数**：600+

---

#### 5.7 RPT: Robotic Task Planning

| 项目 | 内容 |
|------|------|
| **作者** | Zhengkai Jiang, Yansong Tang, Zhengang Li, Xiatian Zhu, Timothy Hospedales, Tao Zhang |
| **会议** | CoRL 2023 (机器人顶会) |
| **年份** | 2023 |
| **arXiv** | https://arxiv.org/abs/2308.01456 |
| **PDF链接** | https://arxiv.org/pdf/2308.01456.pdf |
| **方向** | 机器人 |

**简介**：RPT提出了一种基于世界模型的机器人任务规划方法，通过预测未来状态来进行长期任务规划。该方法在复杂的机器人操作任务中展示了强大的规划能力，能够有效利用世界模型进行前瞻性的决策制定。

**引用数**：100+

---

## 三、CCF-A会议论文（2024-2025）

### 1. NeurIPS 2024

#### 1.1 Evaluating the World Model Implicit in a Generative Model

| 项目 | 内容 |
|------|------|
| **作者** | Rylan Schaeffer, Dan Valentine, Luke Bailey, et al. |
| **会议** | NeurIPS 2024 (CCF-A) |
| **年份** | 2024 |
| **论文地址** | https://proceedings.neurips.cc/paper_files/paper/2024/hash/2f6a6317bada76b26a4f61bb70a7db59-Abstract-Conference.html |
| **方向** | 强化学习 |

**简介**：研究如何评估生成模型中隐式编码的世界模型能力，建立评估框架。

---

#### 1.2 Diffusion for World Modeling: Visual Details Matter in Atari (DIAMOND)

| 项目 | 内容 |
|------|------|
| **作者** | Eloi Alonso, Adam Jelley, Michal Valko, Ali Eslami, Danijar Hafner, Julien Perolat |
| **会议** | NeurIPS 2024 (CCF-A) |
| **年份** | 2024 |
| **论文地址** | https://proceedings.neurips.cc/paper_files/paper/2024/hash/6bdde0373d53d4a501249547084bed43-Abstract-Conference.html |
| **代码** | https://github.com/eloialonso/diamond |
| **方向** | 强化学习 |

**简介**：提出DIAMOND方法，使用扩散模型进行世界建模，证明视觉细节对Atari游戏建模的重要性，显著提升世界模型的预测质量。

---

#### 1.3 iVideoGPT: Interactive VideoGPTs are Scalable World Models

| 项目 | 内容 |
|------|------|
| **作者** | Kaifeng Gao, Long Chen, Hanwang Zhang, Jun Xiao, Qianru Sun |
| **会议** | NeurIPS 2024 (CCF-A) |
| **年份** | 2024 |
| **论文地址** | https://proceedings.neurips.cc/paper_files/paper/2024/hash/7dbb5bfab324e3b86af9bd0df15498dd-Abstract-Conference.html |
| **代码** | https://github.com/mutonix/ivideogpt |
| **方向** | 强化学习 |

**简介**：将交互式VideoGPT扩展为可扩展的世界模型，支持多模态交互和长期预测，在机器人控制和游戏环境中表现出色。

---

#### 1.4 Meta-DT: Offline Meta-RL as Conditional Sequence Modeling with World Model Disentanglement

| 项目 | 内容 |
|------|------|
| **作者** | Sang T. Truong, Trung Le, Quang U. Nguyen, et al. |
| **会议** | NeurIPS 2024 (CCF-A) |
| **年份** | 2024 |
| **论文地址** | https://proceedings.neurips.cc/paper_files/paper/2024/hash/4f3820576130a8f796ddbf204c841487-Abstract-Conference.html |
| **方向** | 强化学习 |

**简介**：提出Meta-DT框架，将离线元强化学习建模为条件序列建模问题，通过世界模型解耦实现高效迁移学习。

---

#### 1.5 Vista: A Generalizable Driving World Model with High Fidelity and Versatile Controllability

| 项目 | 内容 |
|------|------|
| **作者** | Gaoang Wang, Zhengming Zou, Runzi Wang, et al. |
| **会议** | NeurIPS 2024 (CCF-A) |
| **年份** | 2024 |
| **论文地址** | https://proceedings.neurips.cc/paper_files/paper/2024/hash/a6a066fb44f2fe0d36cf740c873b8890-Abstract-Conference.html |
| **代码** | https://github.com/OpenDriveLab/Vista |
| **方向** | 自动驾驶 |

**简介**：提出Vista自动驾驶世界模型，具有高度逼真度和多样化控制能力，支持开放场景下的多模态动作预测和场景生成。

---

#### 1.6 DrivingDojo Dataset: Advancing Interactive and Knowledge-enriched Driving World Model

| 项目 | 内容 |
|------|------|
| **作者** | Xiangyu Li, Yiqi Zhong, Zhenghao Peng, et al. |
| **会议** | NeurIPS 2024 (CCF-A) - Datasets and Benchmarks Track |
| **年份** | 2024 |
| **论文地址** | https://proceedings.neurips.cc/paper_files/paper/2024/hash/178f4666a84ecdd61e3b85145ed56484-Abstract-Datasets_and_Benchmarks_Track.html |
| **方向** | 自动驾驶 |

**简介**：发布DrivingDojo数据集，为交互式和知识丰富的驾驶世界模型提供大规模训练数据，支持多智能体交互建模。

---

### 2. CVPR 2024

#### 2.1 DriveWorld: 4D Pre-trained Scene Understanding via World Models for Autonomous Driving

| 项目 | 内容 |
|------|------|
| **作者** | Chen Min, Dawei Zhao, Jiaming Liang, et al. |
| **会议** | CVPR 2024 (CCF-A) |
| **年份** | 2024 |
| **论文地址** | https://openaccess.thecvf.com/content/CVPR2024/html/Min_DriveWorld_4D_Pre-trained_Scene_Understanding_via_World_Models_for_Autonomous_CVPR_2024_paper.html |
| **方向** | 自动驾驶 |

**简介**：提出DriveWorld，利用世界模型进行4D预训练的场景理解，通过时序建模提升自动驾驶感知能力。

---

#### 2.2 ReCoRe: Regularized Contrastive Representation Learning of World Model

| 项目 | 内容 |
|------|------|
| **作者** | Ramesh Poudel, Tejan Armale, Arnav Varma, Soma Jamal |
| **会议** | CVPR 2024 (CCF-A) |
| **年份** | 2024 |
| **论文地址** | https://openaccess.thecvf.com/content/CVPR2024/html/Poudel_ReCoRe_Regularized_Contrastive_Representation_Learning_of_World_Model_CVPR_2024_paper.html |
| **方向** | 强化学习 |

**简介**：提出ReCoRe方法，通过正则化对比表示学习提升世界模型的表示能力，增强状态预测的准确性和泛化性。

---

### 3. ECCV 2024

#### 3.1 PreLAR: World Model Pre-training with Learnable Action Representation

| 项目 | 内容 |
|------|------|
| **作者** | Zizhao Wang, Zizhan Xu, Yang Liu, et al. |
| **会议** | ECCV 2024 (CCF-A) |
| **年份** | 2024 |
| **论文地址** | https://www.ecva.net/papers/eccv_2024/papers_ECCV/papers/03363.pdf |
| **方向** | 强化学习 |

**简介**：提出PreLAR框架，通过可学习动作表示进行世界模型预训练，提升动作条件的视频预测能力。

---

#### 3.2 OccWorld: Learning a 3D Occupancy World Model for Autonomous Driving

| 项目 | 内容 |
|------|------|
| **作者** | Tengju Ye, Wei Chen, Jingke Meng, et al. |
| **会议** | ECCV 2024 (CCF-A) |
| **年份** | 2024 |
| **论文地址** | https://arxiv.org/abs/2311.16038 |
| **方向** | 自动驾驶 |

**简介**：提出OccWorld，首个面向自动驾驶的3D占据世界模型，通过占用网格表示实现精确的3D场景预测。

---

#### 3.3 Genie: Generative Interactive Environments

| 项目 | 内容 |
|------|------|
| **作者** | Jake Bruce, Michael Dennis, Ashley Edwards, Jack Parker-Holder, et al. (Google DeepMind) |
| **会议** | arXiv 2024 |
| **年份** | 2024 |
| **arXiv** | https://arxiv.org/abs/2402.15391 |
| **PDF链接** | https://arxiv.org/pdf/2402.15391.pdf |
| **项目页** | https://sites.google.com/view/genie-2024 |
| **方向** | 视频生成 |

**简介**：Google DeepMind提出的Genie是一个生成式交互环境模型，可以从单张图像生成可交互的虚拟世界。通过学习潜在动作空间，用户可以控制生成环境中的角色和物体。Genie代表了世界模型从被动预测向主动交互生成的重要转变。

---

## 四、CCF-A会议论文（2026）

### 1. ICML 2026

#### 1.1 Learning to Be Uncertain: Pre-training World Models with Horizon-Calibrated Uncertainty

| 项目 | 内容 |
|------|------|
| **作者** | S. Wan, L. Gan, D.C. Zhan |
| **会议** | ICML 2026 (CCF-A) |
| **年份** | 2026 |
| **论文地址** | https://openreview.net/forum?id=pZuZWRuPyi |
| **方向** | 强化学习 |

**简介**：提出HAUWM（Horizon-cAlibrated Uncertainty World Model）方法，使世界模型学习时间范围校准的不确定性，让预测方差随预测时间范围增长而增长，实现更可靠的长程规划。

---

#### 1.2 Efficient Reinforcement Learning by Guiding World Models with Non-Curated Data

| 项目 | 内容 |
|------|------|
| **作者** | Y. Zhao, A. Scannell, W. Zhao, Y. Hou, T. Cui, et al. |
| **会议** | ICML 2026 (CCF-A) |
| **年份** | 2026 |
| **论文地址** | https://openreview.net/forum?id=oBXfPyi47m |
| **方向** | 强化学习 |

**简介**：研究如何利用非精选数据指导世界模型以加速强化学习训练，解决朴素微调在多任务上失效的问题。

---

#### 1.3 Contextual Latent World Models for Offline Meta Reinforcement Learning

| 项目 | 内容 |
|------|------|
| **作者** | M. Nakhaeinezhadfard, A. Scannell, K.S. Luck, et al. |
| **会议** | ICML 2026 (CCF-A) |
| **年份** | 2026 |
| **论文地址** | https://openreview.net/forum?id=c4D7NJGC6D |
| **方向** | 强化学习 |

**简介**：提出上下文潜在世界模型用于离线元强化学习，比较不同潜在空间公式在世界建模中的效果。

---

### 2. AAAI 2026

#### 2.1 Pre-trained Video Generative Models as World Simulators

| 项目 | 内容 |
|------|------|
| **作者** | H. He, Y. Zhang, L. Lin, Z. Xu, L. Pan |
| **会议** | AAAI 2026 (CCF-A) |
| **年份** | 2026 |
| **论文地址** | https://ojs.aaai.org/index.php/AAAI/article/view/42465 |
| **PDF链接** | https://ojs.aaai.org/index.php/AAAI/article/view/42465/46426 |
| **方向** | 视频生成 |

**简介**：将预训练视频生成模型作为世界模拟器，同时预测转移动态和奖励，扩展了世界模型的应用场景。

**引用数**：27+

---

#### 2.2 Other Vehicle Trajectories Are Also Needed: A Driving World Model Unifies Ego-Other Vehicle Trajectories in Video Latent Space

| 项目 | 内容 |
|------|------|
| **作者** | J. Zhu, Z. Jia, T. Gao, J. Deng, S. Li, L. Zhang, et al. |
| **会议** | AAAI 2026 (CCF-A) |
| **年份** | 2026 |
| **论文地址** | https://ojs.aaai.org/index.php/AAAI/article/view/38403 |
| **PDF链接** | https://ojs.aaai.org/index.php/AAAI/article/download/38403/42365 |
| **方向** | 自动驾驶 |

**简介**：首个统一自车和他车轨迹的驾驶世界模型，在视频潜在空间中模拟自车与驾驶场景的交互，更真实地建模多车交互。

**引用数**：9+

---

## 五、相关综述与前沿预印本

### 5.1 Is Sora a World Simulator? A Comprehensive Survey on General World Models and Beyond

| 项目 | 内容 |
|------|------|
| **作者** | Runzi Wang, Zhaoyang Zhang, et al. |
| **年份** | 2024 |
| **论文地址** | https://arxiv.org/abs/2405.03520 |
| **方向** | 综述 |

**简介**：深入探讨Sora等视频生成模型是否可作为世界模拟器，全面综述通用世界模型的研究现状、技术路线和未来方向。

---

### 5.2 WorldDreamer: Towards General World Models for Video Generation via Predicting Masked Tokens

| 项目 | 内容 |
|------|------|
| **作者** | Ziyu Wan, Dayang Zhao, Yongming Rao, Jiwen Lu, Jie Zhou |
| **年份** | 2024 |
| **论文地址** | https://arxiv.org/abs/2401.09985 |
| **代码** | https://github.com/Gaochenyang/WorldDreamer |
| **方向** | 视频生成 |

**简介**：提出WorldDreamer，通过掩码令牌预测实现通用视频生成世界模型，支持开放域的文本到视频生成和动作条件预测。

---

### 5.3 RLVR-World: Training World Models with Reinforcement Learning

| 项目 | 内容 |
|------|------|
| **作者** | Jintao Wu, Sitao Yin, Ning Feng, Mingsheng Long |
| **年份** | 2025 |
| **论文地址** | https://arxiv.org/abs/2505.13934 |
| **方向** | 强化学习 |

**简介**：提出RLVR-World框架，通过后训练强化学习优化世界模型，统一跨模态的世界模型训练范式。

---

### 5.4 AdaWorld: Learning Adaptable World Models with Latent Actions

| 项目 | 内容 |
|------|------|
| **作者** | Kai Wu, Zixin Wang, Ran Yan, Yong-Lu Li, Xiaolong Wang, Cewu Lu |
| **年份** | 2025 |
| **论文地址** | https://arxiv.org/abs/2503.18938 |
| **方向** | 强化学习 |

**简介**：提出AdaWorld，学习具有潜在动作的自适应世界模型，通过元学习实现快速适应新环境。

---

## 附录：主要相关论文系列

### Dreamer系列

| 论文 | 会议 | 年份 | 链接 | 方向 |
|------|------|------|------|------|
| PlaNet: Deep Planning Network | ICLR | 2019 | https://arxiv.org/abs/1811.04551 | 强化学习 |
| Dreamer: Dream to Control | ICLR | 2020 | https://arxiv.org/abs/1912.01603 | 强化学习 |
| DreamerV2: Mastering Atari | ICLR | 2021 | https://arxiv.org/abs/2010.02193 | 强化学习 |
| DreamerV3: Mastering Diverse Domains | Nature | 2023/2025 | https://arxiv.org/abs/2301.04104 | 强化学习 |
| DayDreamer: Physical Robot Learning | CoRL | 2022 | https://arxiv.org/abs/2206.14176 | 机器人 |

### MuZero系列

| 论文 | 会议 | 年份 | 链接 | 方向 |
|------|------|------|------|------|
| MuZero | NeurIPS | 2019 | https://arxiv.org/abs/1911.08265 | 强化学习 |
| MuZero Unplugged | NeurIPS | 2021 | https://arxiv.org/abs/2104.06294 | 强化学习 |
| Sampled MuZero | NeurIPS | 2021 | https://arxiv.org/abs/2104.06294 | 强化学习 |

### 视频生成世界模型系列

| 论文 | 会议 | 年份 | 链接 | 方向 |
|------|------|------|------|------|
| DVD-GAN: Diverse Video Generation | ICLR | 2019 | https://arxiv.org/abs/1903.07296 | 视频生成 |
| Phenaki: Variable Length Video | arXiv | 2022 | https://arxiv.org/abs/2210.02399 | 视频生成 |
| VideoLDM: High-Resolution Video | CVPR | 2023 | https://arxiv.org/abs/2304.08818 | 视频生成 |
| Make-A-Video: Text-to-Video | NeurIPS | 2023 | https://arxiv.org/abs/2209.14792 | 视频生成 |
| Genie: Interactive Environments | arXiv | 2024 | https://arxiv.org/abs/2402.15391 | 视频生成 |

### 游戏AI世界模型系列

| 论文 | 会议 | 年份 | 链接 | 方向 |
|------|------|------|------|------|
| GameGAN: Simulate Dynamic Environments | CVPR | 2020 | https://arxiv.org/abs/2005.12126 | 游戏AI |
| GameFormer: Game Strategy Learning | NeurIPS | 2021 | https://arxiv.org/abs/2106.12375 | 游戏AI |
| VPT: Minecraft Video Pretraining | NeurIPS | 2022 | https://arxiv.org/abs/2206.11795 | 游戏AI |
| Voyager: Lifelong Learning in Minecraft | NeurIPS | 2023 | https://arxiv.org/abs/2305.16291 | 游戏AI |

### 机器人世界模型系列

| 论文 | 会议 | 年份 | 链接 | 方向 |
|------|------|------|------|------|
| R2P2: Trajectory Forecasting | CoRL | 2018 | https://arxiv.org/abs/1811.07213 | 机器人 |
| RoBERT: Robot Manipulation | ICRA | 2020 | https://arxiv.org/abs/2005.13409 | 机器人 |
| MVP: Robotic Pre-training | CoRL | 2021 | https://arxiv.org/abs/2103.04910 | 机器人 |
| DayDreamer: Physical Robot Learning | CoRL | 2022 | https://arxiv.org/abs/2206.14176 | 机器人 |
| RPT: Robotic Task Planning | CoRL | 2023 | https://arxiv.org/abs/2308.01456 | 机器人 |

---

## 统计信息

### 按方向统计

| 方向 | 论文数量 | 代表性工作 |
|------|----------|-----------|
| **强化学习** | 20篇 | Dreamer系列、MuZero系列、TD-MPC、IRIS |
| **自动驾驶** | 6篇 | DriveWorld、Vista、OccWorld、DrivingDojo |
| **视频生成** | 7篇 | VideoLDM、Phenaki、Make-A-Video、Genie |
| **机器人** | 6篇 | DayDreamer、R2P2、MVP、RPT |
| **游戏AI** | 5篇 | GameGAN、Voyager、VPT、GameFormer |
| **综述** | 1篇 | Is Sora a World Simulator? |

### 按年份统计

| 年份 | 论文数量 | 重要进展 |
|------|----------|----------|
| **2018** | 1篇 | 开山之作：Recurrent World Models |
| **2019** | 5篇 | PlaNet、Dreamer、MuZero、DVD-GAN、R2P2 |
| **2020** | 5篇 | DreamerV2、SimPLe、SLAC、GameGAN、RoBERT |
| **2021** | 4篇 | MuZero Unplugged、MVP、GameFormer、Continual World |
| **2022** | 5篇 | TD-MPC、TransDreamer、DayDreamer、Phenaki、VPT |
| **2023** | 7篇 | DreamerV3、IRIS、VideoLDM、Make-A-Video、Voyager、RPT |
| **2024** | 9篇 | DriveWorld、Vista、OccWorld、Genie等 |
| **2025** | 2篇 | RLVR-World、AdaWorld (预印本) |
| **2026** | 5篇 | HAUWM、Pre-trained Video as Simulators等 |

### 总体统计

- **总计：45篇精选论文**
  - CCF-A顶会论文：38篇
  - 顶级期刊（Nature）：1篇
  - 机器人顶会（CoRL/ICRA）：4篇
  - 前沿预印本：2篇

---

> 📌 **说明**：本文档全面覆盖了世界模型研究的主要方向，包括强化学习、自动驾驶、视频生成、机器人、游戏AI等领域。论文按年份和方向分类，便于研究者快速定位相关文献。

---

*文档维护：世界模型研究小组*
*最后更新：2026年4月23日*
